Start-Transcript -Path 'C:\VeeamISOs\Logs\setup_2_setup_installation.txt'

#region: Setup Directories
Write-Host "Creating required directories for installation" -ForegroundColor Cyan

$InstallSource = 'C:\VeeamISOs'
New-Item -Path 'C:\VeeamISOs\Logs' -ItemType Directory | Out-Null

if (  (Test-Path -Path "$InstallSource") -AND
    (Test-Path -Path "$InstallSource\Logs") ) {
    
    Write-Host "     Directories exist" -ForegroundColor Green
}

#endregion: Setup Directories

<#
#region: Download Installers

Invoke-WebRequest -UseBasicParsing -Uri 'https://www.7-zip.org/a/7z1900-x64.msi' -Outfile "$InstallSource\7z1900-x64.msi"
Invoke-WebRequest -UseBasicParsing -Uri 'https://download.microsoft.com/download/C/4/F/C4F908C9-98ED-4E5F-88D5-7D6A5004AEBD/SQLServer2017-KB4484710-x64.exe' -Outfile "$InstallSource\SQLServer2017-KB4484710-x64.exe"
Invoke-WebRequest -UseBasicParsing -Uri 'https://go.microsoft.com/fwlink/?linkid=2088649' -Outfile "$InstallSource\SSMS-Setup-ENU.exe"

#endregion: Download Installers
#>

<#
#region: Copy Install Files

Write-Host "Creating temporary PSDrive for copying installation files" -ForegroundColor Cyan

New-PSDrive -Name 'T' -PSProvider 'FileSystem' -Root '\\192.168.3.100\T$' -Credential (Get-Credential -UserName PNTLSDESK\jhoughes -Message 'Enter password for PNTLSDESK\jhoughes') | Out-Null

if (Get-PSDrive -Name 'T') {
    Write-Host "     PSDrive created successfully" -ForegroundColor Green
}

Write-Host "Copying installation files" -ForegroundColor Cyan

Copy-Item -Path 'T:\HomeLab\rpoc\7z1900-x64.msi' -Destination $InstallSource
Copy-Item -Path 'T:\HomeLab\rpoc\VeeamBackup&Replication_9.5.4.2753.Update4a.iso' -Destination $InstallSource
Copy-Item -Path 'T:\HomeLab\rpoc\VAS_EntPlus_U4_50instances.lic' -Destination $InstallSource
Copy-Item -Path 'T:\HomeLab\rpoc\en_sql_server_2017_enterprise_x64_dvd_11293666.iso' -Destination $InstallSource
Copy-Item -Path 'T:\HomeLab\rpoc\SQLServer2017-KB4484710-x64.exe' -Destination $InstallSource
Copy-Item -Path 'T:\HomeLab\rpoc\SSMS-Setup-ENU.exe' -Destination $InstallSource
Copy-Item -Path 'T:\HomeLab\rpoc\SQL2017_ConfigurationFile.ini' -Destination $InstallSource

#endregion: Copy Install Files
#>

#region: Install 7-Zip
Write-Host "Installing 7-Zip to unpack ISOs" -ForegroundColor Cyan

$7zip_Arguments = @(
    "/i"
    "$InstallSource\7z1900-x64.msi"
    "/qn"
    "/norestart"
)

Start-Process C:\Windows\System32\msiexec.exe -ArgumentList $7zip_Arguments -Wait -NoNewWindow

#endregion: Install 7-Zip


#region: Check Install Files
Write-Host "Checking installation files" -ForegroundColor Cyan

if (  (Test-Path -Path "$InstallSource\7z1900-x64.msi") -AND
    (Test-Path -Path "$InstallSource\VeeamBackup&Replication_9.5.4.2753.Update4a.iso") -AND
    (Test-Path -Path "$InstallSource\VAS_EntPlus_U4_50instances.lic") -AND
    (Test-Path -Path "$InstallSource\en_sql_server_2017_enterprise_x64_dvd_11293666.iso") -AND
    (Test-Path -Path "$InstallSource\SQLServer2017-KB4484710-x64.exe") -AND
    (Test-Path -Path "$InstallSource\SSMS-Setup-ENU.exe") -AND
    (Test-Path -Path "$InstallSource\SQL2017_ConfigurationFile.ini") ) {
    
    Write-Host "     Installation files exist" -ForegroundColor Green
}

#endregion: Copy Install Files


#region: Unpack Install Files
Push-Location $InstallSource


Write-Host "Unpacking Veeam ISO" -ForegroundColor Cyan

& 'C:\Program Files\7-Zip\7z.exe' x 'C:\VeeamISOs\VeeamBackup&Replication_9.5.4.2753.Update4a.iso' -o'C:\VeeamISOs\VAS_9.5_U4a\' | Out-Null

Write-Host "Unpacking SQL ISO" -ForegroundColor Cyan

& 'C:\Program Files\7-Zip\7z.exe' x 'C:\VeeamISOs\en_sql_server_2017_enterprise_x64_dvd_11293666.iso' -o'C:\VeeamISOs\SQL2017\' | Out-Null

if (  (Test-Path -Path "$InstallSource\VAS_9.5_U4a\Backup\Server.x64.msi") -AND
    (Test-Path -Path "$InstallSource\SQL2017\setup.exe") ) {
    
    Write-Host "     ISO files unpacked successfully" -ForegroundColor Green
}

<#
Write-Host "Deleting ISOs" -ForegroundColor Cyan

Remove-Item 'C:\VeeamISOs\VeeamBackup&Replication_9.5.4.2753.Update4a.iso' | Out-Null
Remove-Item 'C:\VeeamISOs\en_sql_server_2017_enterprise_x64_dvd_11293666.iso' | Out-Null
#>

Pop-Location
#endregion: Unpack Install Files


#region: New Local Administrator
$username = 'svc_veeam_poc'
$fulluser = $env:COMPUTERNAME + '\' + $username
$password = 'Passw0rd!'

Write-Host "Creating local user '$fulluser' with password '$password' ..." -ForegroundColor Cyan
New-LocalUser -Name $username -Password ($password | ConvertTo-SecureString -AsPlainText -Force) -Description "Service Account for Veeam" -AccountNeverExpires -ErrorAction Stop | Out-Null
Add-LocalGroupMember -Group "Administrators" -Member $username -ErrorAction Stop
If (Get-LocalUser -Name $username) {
    Write-Host "     Created local user '$fulluser'" -ForegroundColor Green
}
#endregion New Local Administrator

Stop-Transcript