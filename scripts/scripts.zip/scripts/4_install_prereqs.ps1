Start-Transcript -Path 'C:\VeeamISOs\Logs\setup_4_install_prereqs.txt'

#region: Variables
$InstallSource = Get-Item -Path 'C:\VeeamISOs'
$LogDir = Get-Item -Path 'C:\VeeamISOs\Logs'
#endregion: Variables

#region: Install Prerequisites

Write-Host "Installing Veeam Prerequisites" -ForegroundColor Cyan
Write-Host "------------------------------" -ForegroundColor Cyan

Write-Host "Installing SQL 2014 CLR" -ForegroundColor Cyan

$SQL2014_CLR_Arguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Redistr\x64\SQLSysClrTypes.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\_Prereq_01_SQL2014_CLR.txt"
)

Start-Process C:\Windows\System32\msiexec.exe -ArgumentList $SQL2014_CLR_Arguments -Wait -NoNewWindow

if (Select-String -Path "$LogDir\_Prereq_01_SQL2014_CLR.txt" -Pattern "Installation success or error status: 0.") {
    Write-Host "     SQL 2014 CLR Install Succeeded" -ForegroundColor Green
}
else {
    $Prereq_Failures += 1
    throw "SQL 2014 CLR Install Failed"
}

Write-Host "Installing SQL 2014 SMO"  -ForegroundColor Cyan
$SQL2014_SMO_Arguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Redistr\x64\SharedManagementObjects.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\_Prereq_02_SQL2014_SMO.txt"
)

Start-Process C:\Windows\System32\msiexec.exe -ArgumentList $SQL2014_SMO_Arguments -Wait -NoNewWindow

if (Select-String -Path "$LogDir\_Prereq_02_SQL2014_SMO.txt" -Pattern "Installation success or error status: 0.") {
    Write-Host "     SQL 2014 SMO Install Succeeded" -ForegroundColor Green
}
else {
    $Prereq_Failures += 1
    throw "SQL 2014 SMO Install Failed"
}

Write-Host "Installing MS Report Viewer 2015" -ForegroundColor Cyan
$MS2015_ReportViewer_Arguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Redistr\ReportViewer.msi"
    "/qn"
    "/norestart"
    "/L*v"                                          
    "$LogDir\_Prereq_03_MS_ReportViewer2015.txt"
)

Start-Process C:\Windows\System32\msiexec.exe -ArgumentList $MS2015_ReportViewer_Arguments -Wait -NoNewWindow

if (Select-String -Path "$LogDir\_Prereq_03_MS_ReportViewer2015.txt" -Pattern "Installation success or error status: 0.") {
    Write-Host "     MS Report Viewer 2015 Install Succeeded" -ForegroundColor Green
}
else {
    $Prereq_Failures += 1
    throw "MS Report Viewer 2015 Install Failed"
}


If ($Prereq_Failures -gt 0) {
    throw "One or more Prerequisites failed to Install.  Exiting Build Script"
}


#region: Install MS SQL
Write-Host "Installing SQL 2017" -ForegroundColor Cyan

$SQL2017_Arguments = @(
    "/ConfigurationFile=$InstallSource\SQL2017_ConfigurationFile.ini"
)

Start-Process "$InstallSource\SQL2017\setup.exe" -ArgumentList $SQL2017_Arguments -Wait -NoNewWindow | Out-Null

if (Select-String -Path "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log\Summary.txt" -Pattern "Exit code \(Decimal\):           0") {
    Write-Host "     SQL 2017 Install Succeeded" -ForegroundColor Green
}
else {
    $Prereq_Failures += 1
    throw "SQL 2017 Install Failed"
}

Write-Host "Installng SQL 2017 CU14" -ForegroundColor Cyan

$SQL2017_CU14_Arguments = @(
    "/QUIET"
    "/IAcceptSQLServerLicenseTerms"
    "/Action=Patch"
    "/InstanceName=VEEAMSQL2016"
)

Start-Process "$InstallSource\SQLServer2017-KB4484710-x64.exe" -ArgumentList $SQL2017_CU14_Arguments -Wait -NoNewWindow | Out-Null

if (((Select-String -Path "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log\Summary.txt" -Pattern "Exit code \(Decimal\):           0") -OR (Select-String -Path "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log\Summary.txt" -Pattern "Passed but reboot required")) -and (Select-String -Path "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log\Summary.txt" -Pattern "KBArticle:                     KB4484710")) {
    Write-Host "     SQL 2017 CU14 Install Succeeded" -ForegroundColor Green
}
else {
    $Prereq_Failures += 1
    throw "SQL 2017 CU14 Install Failed"
}

<#
Write-Host "Installing SSMS 17.9.1" -ForegroundColor Cyan

$SSMS18_Arguments = @(
    "/install"
    "/quiet"
    "/norestart"
    "/log"
    "$LogDir\_Prereq_04_SSMS_17.9.1.txt"
)

Start-Process "$InstallSource\SSMS-Setup-ENU.exe" -ArgumentList $SSMS18_Arguments -Wait -NoNewWindow

if ((Select-String -Path "$LogDir\_Prereq_04_SSMS_17.9.1.txt" -Pattern "Install Completed for package SQL Server Management Studio") -AND (Select-String -Path "$LogDir\_Prereq_04_SSMS_17.9.1.txt" -Pattern "Applied execute package: SsmsPostInstall_x64, result: 0x0") -AND (Select-String -Path "$LogDir\_Prereq_04_SSMS_17.9.1.txt" -Pattern "Apply complete, result: 0x0")) {
    Write-Host "     SSMS 17.9.1 Install Succeeded" -ForegroundColor Green
}
else {
    $Prereq_Failures += 1
    throw "SSMS 17.9.1 Install Failed"
}
#>

#endregion Install MS SQL

Write-Host "------------------------------" -ForegroundColor Cyan
if (!$Prereq_Failures) {
    Write-Host "     Veeam Prerequisites Successfully Installed" -ForegroundColor Green
}
else {
    throw "Installation of $Prereq_Failures prerequisites failed"
}

#endregion Install Prerequisites


Stop-Transcript