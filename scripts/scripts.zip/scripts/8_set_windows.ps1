Start-Transcript -Path 'C:\VeeamISOs\Logs\8_set_windows.txt'

#Set account lockout settings
net accounts /lockoutthreshold:10
net accounts /lockoutduration:30
net accounts /lockoutwindow:30

#Imkport security DB
Secedit /configure /db secedit.sdb /cfg"C:\VeeamISOs\scripts\veeampoc.inf" >nul

#Disable the Windows Error reporting settings
$path1 = 'HKLM:\SOFTWARE\Policies\Microsoft\PCHealth\ErrorReporting'
try {
    $setting1 = (Get-ItemProperty -ErrorAction Stop -Name DoReport -Path $path1).DoReport 
    if ($setting1 -ne 0) {
        Set-ItemProperty -Path $path1 -Name 'DoReport' -Value 0  
    }
}
catch {
    New-ItemProperty -Path $path1 -Name 'DoReport' -Value 0 -PropertyType 'DWORD'
}

$path2 = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting'
try {
    $setting2 = (Get-ItemProperty -ErrorAction Stop -Name Disabled -Path $path2).Disabled 
    if ($setting2 -ne 1) {
        Set-ItemProperty -Path $path2 -Name 'Disabled' -Value 1  
    }
}
catch {
    New-ItemProperty -Path $path2 -Name 'Disabled' -Value 1 -PropertyType 'DWORD'
}

#Set password prompt and disconnection time for RDP
$path3 = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'
try {
    $setting3 = (Get-ItemProperty -ErrorAction Stop -Name fPromptForPassword -Path $path3).fPromptForPassword 
    if ($setting3 -ne 1) {
        Set-ItemProperty -Path $path3 -Name 'DoReport' -Value 1  
    }
}
catch {
    New-ItemProperty -Path $path3 -Name 'DoReport' -Value 1 -PropertyType 'DWORD'
}

try {
    $setting4 = (Get-ItemProperty -ErrorAction Stop -Name fPromptForPassword -Path $path3).MaxDisconnectionTime 
    if ($setting4 -ne 60000) {
        Set-ItemProperty -Path $path3 -Name 'MaxDisconnectionTime' -Value 60000  
    }
}
catch {
    New-ItemProperty -Path $path3 -Name 'MaxDisconnectionTime' -Value 60000 -PropertyType 'DWORD'
}

#Clearing Event Logs
(Get-WinEvent -ListLog *).logname | ForEach-Object {[System.Diagnostics.Eventing.Reader.EventLogSession]::GlobalSession.ClearLog("$psitem")}

Wevtutil el | ForEach { wevtutil cl "$_"}


#Verify Settings
Write-Host "Verifying Settings" -ForegroundColor Cyan
Write-Host "------------------------------" -ForegroundColor Cyan

#Verify Windows Error reporting settings
if ((Get-ItemProperty -Name ComputerName -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PCHealth\ErrorReporting').DoReport -eq 'VEEAMPOC') {
    Write-Host -ForegroundColor Green 'Computer name is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Computer name is not set correctly.'
}

if ((Get-ItemProperty -Name ComputerName -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting').Disabled -eq 'VEEAMPOC') {
    Write-Host -ForegroundColor Green 'Computer name is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Computer name is not set correctly.'
}

#Verify password prompt and disconnection time for RDP
if ((Get-ItemProperty -Name ComputerName -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services').fPromptForPassword -eq 'VEEAMPOC') {
    Write-Host -ForegroundColor Green 'Computer name is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Computer name is not set correctly.'
}

if ((Get-ItemProperty -Name ComputerName -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services').MaxDisconnectionTime -eq 'VEEAMPOC') {
    Write-Host -ForegroundColor Green 'Computer name is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Computer name is not set correctly.'
}

#Export user rights settings
secedit /export /areas USER_RIGHTS /cfg C:\VeeamISOs\Logs\UserRights.txt

Stop-Transcript