Start-Transcript -Path 'C:\VeeamISOs\Logs\setup_3_format_repo.txt'


$cd = $NULL
$cd = Get-WMIObject -Class Win32_CDROMDrive -ComputerName $env:COMPUTERNAME -ErrorAction Stop
if ($cd.Drive -eq "D:") {
    Write-Output "Changing CD Drive letter from D: to E:"
    Set-WmiInstance -InputObject ( Get-WmiObject -Class Win32_volume -Filter "DriveLetter = 'D:'" ) -Arguments @{DriveLetter = 'E:'}
}

$New_Disk = Get-Disk | Where-Object {$PSItem.IsOffline -eq $True -AND $PSItem.PartitionStyle -eq 'RAW'}
$New_Disk | Set-Disk -IsOffline $False
Initialize-Disk -Number $New_Disk.DiskNumber -PartitionStyle GPT | Out-Null
New-Partition -DiskNumber $New_Disk.DiskNumber -DriveLetter D -GptType '{ebd0a0a2-b9e5-4433-87c0-68b6b72699c7}' -UseMaximumSize | Out-Null
Format-Volume -DriveLetter D -FileSystem ReFS -NewFileSystemLabel Veeam_Repo -AllocationUnitSize 65536 | Out-Null

if ((Get-Volume -DriveLetter D | Select-Object -ExpandProperty FileSystem) -eq 'ReFS') {
    Write-Host -ForegroundColor Green 'Repository drive has been created.'
}
else {
    Write-Host -ForegroundColor Red 'Repository drive has not been created.'
}

Stop-Transcript