Start-Transcript -Path 'C:\VeeamISOs\Logs\setup_1_setup_server.txt'

#Rename computer
Rename-Computer -NewName 'VEEAMPOC'

#Set the 'Adjust for best performance' setting
$path1 = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'
try {
    $setting1 = (Get-ItemProperty -ErrorAction Stop -Name VisualFXSetting -Path $path1).VisualFXSetting 
    if ($setting1 -ne 2) {
        Set-ItemProperty -Path $path1 -Name 'VisualFXSetting' -Value 2  
        }
    }
catch {
    New-ItemProperty -Path $path1 -Name 'VisualFXSetting' -Value 2 -PropertyType 'DWORD'
}

#Set OS display timeout
bcdedit /timeout 5 | Out-Null

#Disable Server Manager at startup
$path2 = 'HKCU:\Software\Microsoft\ServerManager'
try {
    $setting2 = (Get-ItemProperty -ErrorAction Stop -Name DoNotOpenServerManagerAtLogon -Path $path2).DoNotOpenServerManagerAtLogon 
    if ($setting2 -ne 1) {
        Set-ItemProperty -Path $path2 -Name 'DoNotOpenServerManagerAtLogon' -Value 1  
    }
}
catch {
    New-ItemProperty -Path $path2 -Name 'DoNotOpenServerManagerAtLogon' -Value 1 -PropertyType 'DWORD'
}

try {
    $setting3 = (Get-ItemProperty -ErrorAction Stop -Name CheckedUnattendLaunchSetting -Path $path2).CheckedUnattendLaunchSetting 
    if ($setting3 -ne 0) {
        Set-ItemProperty -Path $path2 -Name 'CheckedUnattendLaunchSetting' -Value 0  
    }
}
catch {
    New-ItemProperty -Path $path2 -Name 'CheckedUnattendLaunchSetting' -Value 0 -PropertyType 'DWORD'
}

Get-ScheduledTask -TaskName ServerManager | Disable-ScheduledTask | Out-Null

#Disable Windows Firewall
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

#Disable Windows hibernation
powercfg -h off

#Set High Performance power configuration
powercfg /s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c

#Enable Windows Data deduplication
Install-WindowsFeature -Name FS-Data-Deduplication | Out-Null

#Verify Settings
Write-Host "Verifying Settings" -ForegroundColor Cyan
Write-Host "------------------------------" -ForegroundColor Cyan

#Verify rename
if ((Get-ItemProperty -Name ComputerName -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName').ComputerName -eq 'VEEAMPOC') {
    Write-Host -ForegroundColor Green 'Computer name is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Computer name is not set correctly.'
}

#Verify visual "best performance" setting
if ((Get-ItemProperty -Name visualfxsetting -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects').VisualFXSetting -eq '2') {
    Write-Host -ForegroundColor Green 'Visual Performance setting is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Visual Performance is not set correctly.'
}

#Verify OS timeout display
if (((bcdedit /enum | Select-String timeout).ToString()) -eq "timeout                 5") {
    Write-Host -ForegroundColor Green 'Operating system timeout setting is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Operating system timeout is not set correctly.'
}

#Verify Server Manager disabled at startup

if ((Get-ItemProperty -Name DoNotOpenServerManagerAtLogon -Path 'HKCU:\Software\Microsoft\ServerManager').DoNotOpenServerManagerAtLogon -eq 1) {
    Write-Host -ForegroundColor Green 'DoNotOpenServerManagerAtLogon setting is correct.'
}
else {
    Write-Host -ForegroundColor Red 'DoNotOpenServerManagerAtLogon is not set correctly.'
}

if ((Get-ItemProperty -Name CheckedUnattendLaunchSetting -Path 'HKCU:\Software\Microsoft\ServerManager').CheckedUnattendLaunchSetting -eq 0) {
    Write-Host -ForegroundColor Green 'CheckedUnattendLaunchSetting setting is correct.'
}
else {
    Write-Host -ForegroundColor Red 'CheckedUnattendLaunchSetting is not set correctly.'
}

if ((Get-ScheduledTask -TaskName ServerManager).State -eq 'Disabled') {
    Write-Host -ForegroundColor Green 'Server manager scheduled task setting is correct.'
}
else {
    Write-Host -ForegroundColor Red 'Server manager scheduled task is not set correctly.'
}

#Verify Windows Firewall disabled
if (((Get-NetFirewallProfile -Profile Domain).Enabled -eq 'False') -AND ((Get-NetFirewallProfile -Profile Public).Enabled -eq 'False') -AND ((Get-NetFirewallProfile -Profile Private).Enabled -eq 'False')) {
    Write-Host -ForegroundColor Green 'Firewall profile settings are correct.'
}
else {
    Write-Host -ForegroundColor Red 'Firewall profiles are not set correctly.'
}

#Verify Windows hibernation disabled
if ((powercfg /a | Select-String 'The system firmware does not support hibernation.' -Quiet)) {
    Write-Host -ForegroundColor Green 'Hibernation is disabled.'
}
else {
    Write-Host -ForegroundColor Red 'Hibernation is not disabled.'
}

#Verify High Performance power configuration
if ((powercfg /getactivescheme | Select-String 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c -Quiet)) {
    Write-Host -ForegroundColor Green 'High performance power plan is set.'
}
else {
    Write-Host -ForegroundColor Red 'High performance power plan is not set correctly.'
}

#Verify Windows Data deduplication
if ((Get-WindowsFeature -Name FS-Data-Deduplication | Select-Object -ExpandProperty InstallState) -eq 'Installed') {
    Write-Host -ForegroundColor Green 'Windows Data deduplication is installed.'
}
else {
    Write-Host -ForegroundColor Red 'Windows Data deduplication is not installed.'
}

#Verify VeeamISOs directory
if ( Test-Path -Path 'C:\VeeamISOs') {
        Write-Host -ForegroundColor Green 'Install directory exists.'
}
else {
    Write-Host -ForegroundColor Red 'Install directory not created.'
}

Stop-Transcript

#Reboot Server
Restart-Computer -Confirm

