Start-Transcript -Path 'C:\VeeamISOs\Logs\setup_5_install_veeam_br_bem.txt'

#region: Variables
$InstallSource = 'C:\VeeamISOs'
$LogDir = 'C:\VeeamISOs\Logs'
$licensefile = "$InstallSource\Veeam-100instances-entplus-monitoring-nfr.lic"
$username = 'svc_veeam_poc'
$fulluser = $env:COMPUTERNAME + '\' + $username
$password = 'Passw0rd!'
$CatalogPath = 'C:\VBRCatalog'
$vPowerPath = 'C:\vPowerNfs'
#endregion

#region: Install Veeam Components

Write-Host "Installing Veeam Backup & Replication" -ForegroundColor Cyan
Write-Host "------------------------------" -ForegroundColor Cyan

#region: Install Backup Catalog
Write-Host "Installing Backup Catalog" -ForegroundColor Cyan
New-Item -ItemType Directory -path $CatalogPath | Out-Null
$Backup_Catalog_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Catalog\VeeamBackupCatalog64.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\01_Catalog.txt"
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
    "VM_CATALOGPATH=$CatalogPath"
    "VBRC_SERVICE_USER=$fulluser"
    "VBRC_SERVICE_PASSWORD=$password"
)
Start-Process "msiexec.exe" -ArgumentList $Backup_Catalog_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\01_Catalog.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Backup Catalog Install Succeeded" -ForegroundColor Green
}
else {
    throw "Backup Catalog Install Failed"
}
#endregion: Install Backup Catalog

#region: Install Backup Server
Write-Host "Installing Backup Server" -ForegroundColor Cyan
New-Item -ItemType Directory -path $vPowerPath | Out-Null
$Backup_Server_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Backup\Server.x64.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\02_Backup.txt"
    "ACCEPTEULA=YES"
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
    "VBR_LICENSE_FILE=$licensefile"
    "VBR_SERVICE_USER=$fulluser"
    "VBR_SERVICE_PASSWORD=$password"
    "VBR_NFSDATASTORE=$vPowerPath"
    "VBR_SQLSERVER_SERVER=$env:COMPUTERNAME\VEEAMSQL2016"
)
Start-Process "msiexec.exe" -ArgumentList $Backup_Server_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\02_Backup.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Backup Server Install Succeeded" -ForegroundColor Green
}
else {
    throw "Backup Server Install Failed"
}

#endregion: Install Backup Server

#region: Install Backup Console
Write-Host "Installing Backup Console" -ForegroundColor Cyan
$Backup_Console_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Backup\Shell.x64.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\03_Console.txt"
    "ACCEPTEULA=YES"
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $Backup_Console_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\03_Console.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Backup Console Install Succeeded" -ForegroundColor Green
}
else {
    throw "Setup Failed"
}
#endregion: Install Backup Console

#region: Install Explorers
Write-Host "Installing Explorer For Active Directory" -ForegroundColor Cyan
$Explorer_AD_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Explorers\VeeamExplorerForActiveDirectory.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\04_ExplorerForActiveDirectory.txt"
    "ACCEPT_EULA=`"1`""
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $Explorer_AD_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\04_ExplorerForActiveDirectory.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Explorer For Active Directory Install Succeeded" -ForegroundColor Green
}
else {
    throw "Explorer For Active Directory Install Failed"
}

Write-Host "Installing Explorer For Exchange" -ForegroundColor Cyan
$Explorer_Exchange_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Explorers\VeeamExplorerForExchange.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\05_VeeamExplorerForExchange.txt"
    "ACCEPT_EULA=`"1`""
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $Explorer_Exchange_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\05_VeeamExplorerForExchange.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Explorer For Exchange Install Succeeded" -ForegroundColor Green
}
else {
    throw "Explorer For Exchange Install Failed"
}

Write-Host "Installing Explorer For SQL" -ForegroundColor Cyan
$Explorer_SQL_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Explorers\VeeamExplorerForSQL.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\06_VeeamExplorerForSQL.txt"
    "ACCEPT_EULA=`"1`""
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $Explorer_SQL_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\06_VeeamExplorerForSQL.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Explorer For SQL Succeeded" -ForegroundColor Green
}
else {
    throw "Explorer For SQL Install Failed"
}

Write-Host "Installing Explorer For Oracle" -ForegroundColor Cyan
$Explorer_Oracle_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Explorers\VeeamExplorerForOracle.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\07_VeeamExplorerForOracle.txt"
    "ACCEPT_EULA=`"1`""
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $Explorer_Oracle_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\07_VeeamExplorerForOracle.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Explorer For Oracle Succeeded" -ForegroundColor Green
}
else {
    throw "Explorer For Oracle Install Failed"
}

Write-Host "Installing Explorer For SharePoint" -ForegroundColor Cyan
$Explorer_Sharepoint_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Explorers\VeeamExplorerForSharePoint.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\08_VeeamExplorerForSharePoint.txt"
    "ACCEPT_EULA=`"1`""
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $Explorer_Sharepoint_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\08_VeeamExplorerForSharePoint.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Explorer For SharePoint Install Succeeded" -ForegroundColor Green
}
else {
    throw "Explorer For SharePoint Install Failed"
}
#endregion: Install Explorers

#endregion: Install Veeam Components


#region: Install Enterprise Manager
Write-Host "Installing Enterprise Manager" -ForegroundColor Cyan
Write-Host "------------------------------" -ForegroundColor Cyan

#region: Install Enterprise Manager Prerequisites
Write-Host "Installing Enterprise Manager Prerequisites" -ForegroundColor Cyan
Install-WindowsFeature Web-Default-Doc, Web-Dir-Browsing, Web-Http-Errors, Web-Static-Content, Web-Windows-Auth -Restart:$false | Out-Null
Install-WindowsFeature Web-Http-Logging, Web-Stat-Compression, Web-Filtering, Web-Net-Ext45, Web-Asp-Net45, Web-ISAPI-Ext, Web-ISAPI-Filter, Web-Mgmt-Console -Restart:$false | Out-Null

$URLRewrite_IIS_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Redistr\x64\rewrite_amd64.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\_Prereq_04_URLRewrite_IIS.txt"
    "ACCEPTEULA=YES"
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $URLRewrite_IIS_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\_Prereq_04_URLRewrite_IIS.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     URL Rewrite Module for IIS Install Succeeded" -ForegroundColor Green
}
else {
    $Prereq_Failures += 1
    throw "URL Rewrite Module for IIS Install Failed"
}

#endregion: Install Enterprise Manager Prerequisites

#region: Install Enterprise Manager Web
Write-Host "Installing Enterprise Manager Web" -ForegroundColor Cyan
$Enterprise_Manager_Web_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\EnterpriseManager\BackupWeb_x64.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\09_EntWeb.txt"
    "ACCEPTEULA=YES"
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
    "VBREM_LICENSE_FILE=$licensefile"
    "VBREM_SERVICE_USER=$fulluser"
    "VBREM_SERVICE_PASSWORD=$password"
    "VBREM_SQLSERVER_SERVER=$env:COMPUTERNAME\VEEAMSQL2016"
)
Start-Process "msiexec.exe" -ArgumentList $Enterprise_Manager_Web_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\09_EntWeb.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Enterprise Manager Web Install Succeeded" -ForegroundColor Green
}
else {
    throw "Enterprise Manager Web Install Failed"
}

#endregion: Install Enterprise Manager Web


<#
#region: Install Enterprise Manager Cloud Portal
Write-Host "Installing Enterprise Manager Cloud Portal" -ForegroundColor Cyan

$Enterprise_Manager_CloudPortal_MSIArguments = @(
    "/i"
    "$InstallSource\VAS_9.5_U4a\Cloud Portal\BackupCloudPortal_x64.msi"
    "/L*v"
    "$LogDir\14_EntCloudPortal.txt"
    "/qn"
    "ACCEPTEULA=YES"
)
Start-Process "msiexec.exe" -ArgumentList $Enterprise_Manager_CloudPortal_MSIArguments -Wait -NoNewWindow

if (Select-String -path "$LogDir\14_EntCloudPortal.txt" -pattern "Installation success or error status: 0.") {
    Write-Host "     Enterprise Manager Cloud Install Succeeded" -ForegroundColor Green
}
else {
    throw "Enterprise Manager Cloud Install Failed"
}

#endregion: Install Enterprise Manager Cloud Portal
#>

#endregion: Install Enterprise Manager

<#
#region: Install Veeam 9.5U4a Patch
Write-Host "Installing Veeam 9.4 U4a Patch" -ForegroundColor Cyan
Write-Host "------------------------------" -ForegroundColor Cyan

$Veeam_95_U4a_Patch_Arguments = @(
    "/silent"
    "/noreboot"
    "/log"
    "$LogDir\Patch_Veeam_9.5_U4a.log"
    "VBR_AUTO_UPGRADE=YES"
)
Start-Process "C:\VeeamISOs\VAS_9.5_U4a\Updates\veeam_backup_9.5.4.2753.update4a_setup.exe" -ArgumentList $Veeam_95_U4a_Patch_Arguments -Wait -NoNewWindow



#endregion: Install Veeam 9.5U4a Patch



#region: Install Updated Backup Console
Write-Host "Installing 9.5 U4a Backup Console" -ForegroundColor Cyan
$95U4a_Backup_Console_MSIArguments = @(
    "/i"
    "C:\Program Files\Veeam\Backup and Replication\Backup\Updates\Shell.x64.msi"
    "/qn"
    "/norestart"
    "/L*v"
    "$LogDir\Patch_Veeam_9.5_U4a_Console.txt"
    "ACCEPTEULA=YES"
    "ACCEPT_THIRDPARTY_LICENSES=`"1`""
)
Start-Process "msiexec.exe" -ArgumentList $95U4a_Backup_Console_MSIArguments -Wait -NoNewWindow

& msiexec.exe /i 'C:\Program Files\Veeam\Backup and Replication\Backup\Updates\Shell.x64.msi' /qn /norestart /L*v C:\VeeamISOs\Logs\Patch_Veeam_9.5_U4a_Console.txt ACCEPTEULA=YES ACCEPT_THIRDPARTY_LICENSES="1"

#endregion: Install Backup Console


#>


Stop-Transcript

