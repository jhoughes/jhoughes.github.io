﻿Start-Transcript -Path 'C:\VeeamISOs\Logs\setup_7_set_sql.txt'

$fulluser = $env:COMPUTERNAME + '\' + $username
$password = 'Passw0rd!'
$LogDir = Get-Item -Path 'C:\VeeamISOs\Logs'

#Set SQL authentication to Windows only
$path = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.VEEAMSQL2016\MSSQLServer'
try {
    $setting = (Get-ItemProperty -ErrorAction Stop -Name LoginMode -Path $path).LoginMode 
    if ($setting -ne 1) {
        Set-ItemProperty -Path $path -Name 'LoginMode' -Value 1  
        }
    }
catch {
    New-ItemProperty -Path $path -Name 'LoginMode' -Value 1 -PropertyType 'DWORD'
}


$Query1="EXECUTE sp_configure 'show advanced options', 1;
RECONFIGURE;
EXECUTE sp_configure 'Ad Hoc Distributed Queries', 0;
RECONFIGURE;
GO
EXECUTE sp_configure 'show advanced options', 0;
RECONFIGURE;
"


$Query2 ="EXEC master..xp_instance_regwrite
@rootkey = N'HKEY_LOCAL_MACHINE',
@key = N'SOFTWARE\Microsoft\Microsoft SQL Server\MSSQLServer\SuperSocketNetLib',
@value_name = N'HideInstance',
@type = N'REG_DWORD',
@value = 1;
"

$Query3 = "
USE [master]
GO
DECLARE @tsql nvarchar(max)
SET @tsql = 'ALTER LOGIN ' + SUSER_NAME(0x01) + ' DISABLE'
EXEC (@tsql)
GO
"


$Query4 = "select name,is_disabled from sys.sql_logins Where Name ='sa'"

Import-Module SQLPS

Set-Location 'SQLSERVER:\SQL\VEEAMPOC\VEEAMSQL2016'

& {Invoke-Sqlcmd -Username $fulluser -Password $password -Query $Query1 -Verbose} 4> "$LogDir\sql_disable_adhoc_dist_queries.txt"

Invoke-Sqlcmd -Username $fulluser -Password $password -Query $Query2

& {Invoke-Sqlcmd -Username $fulluser -Password $password -Query $Query3 -Verbose} 4> "$LogDir\sql_hide_instance.txt"



#Verify SQL Authentication Mode
if ((Get-ItemProperty -Name LoginMode -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.VEEAMSQL2016\MSSQLServer').LoginMode -eq '1') {
    Write-Host -ForegroundColor Green 'SQL Authentication Mode is Windows authentication Only.'
}
else {
    Write-Host -ForegroundColor Red 'SQL Authentication Mode is not set correctly.'
}

#Verify sa account disabled
if ((Invoke-Sqlcmd -Username $fulluser -Password $password -Query $Query4 -Verbose).is_disabled) {
    Write-Host -ForegroundColor Green 'SQL sa account is disabled.'
}
else {
    Write-Host -ForegroundColor Red 'SQL sa account is not disabled.'
}

#Verify SQL Instance Hidden
if ((Get-ItemProperty -Name HideInstance -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.VEEAMSQL2016\MSSQLServer\SuperSocketNetLib').HideInstance -eq '1') {
    Write-Host -ForegroundColor Green 'SQL Instance is hidden.'
}
else {
    Write-Host -ForegroundColor Red 'SQL Instance is not hidden.'
}

Stop-Transcript