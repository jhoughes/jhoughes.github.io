Start-Transcript -Path 'C:\VeeamISOs\Logs\setup_6_configure_veeam_br_bem.txt'

#Configure repository and move config backup
Add-PSSnapIn -Name VeeamPSSnapIn
Connect-VBRServer

$DefaultServer = Get-VBRServer -Name 'VEEAMPOC'
$NewRepo = Add-VBRBackupRepository -Name 'POC_Backup_Repository' -Description 'Veeam POC Backup Repository' -Server $DefaultServer -Folder 'D:\Backups' -Type WinLocal

Set-VBRConfigurationBackupJob -Repository $NewRepo
Get-VBRBackupRepository -Name 'Default Backup Repository' | Remove-VBRBackupRepository -Confirm:$false

#Due to self-signed cert 
Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

$password = ConvertTo-SecureString 'Passw0rd!' -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential ('svc_veeam_poc', $password)

#Get the API
$r_api = Invoke-WebRequest -Method Get -Uri "http://localhost:9399/api/" 
$r_api_xml = [xml]$r_api.Content
$r_api_links = @($r_api_xml.EnterpriseManager.SupportedVersions.SupportedVersion | Where-Object { $_.Name -eq "v1_4" })[0].Links

#Login
$r_login = Invoke-WebRequest -Method Post -Uri $r_api_links.Link.Href -Credential $credential

#Set headers
$sessionheadername = "X-RestSvcSessionId"
$sessionid = $r_login.Headers[$sessionheadername]

#Get API content
$r_login_xml = [xml]$r_login.Content
$r_login_links = $r_login_xml.LogonSession.Links.Link
$r_login_links_base = $r_login_links | Where-Object {$_.Type -eq 'EnterpriseManager'}

#Add backup server request
$RequestBody = @"
<?xml version="1.0" encoding="utf-8"?>
<BackupServerSpec xmlns="http://www.veeam.com/ent/v1.0" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<Description>Veeam POC Server</Description>
<DnsNameOrIpAddress>VEEAMPOC</DnsNameOrIpAddress>
<Port>9392</Port>
<Username>VEEAMPOC\svc_veeam_poc</Username>
<Password>Passw0rd!</Password>
</BackupServerSpec>
"@

$r_server_add_uri = $r_login_links_base.Href + 'backupServers?action=create'
Invoke-WebRequest -Method POST -Headers @{$sessionheadername = $sessionid} -Uri $r_server_add_uri -Body $RequestBody -ContentType application/xml

#Get backup server list
$r_server_query_uri = $r_login_links_base.Href + 'backupServers'
$r_server_query = Invoke-WebRequest -Method Get -Headers @{$sessionheadername = $sessionid} -Uri $r_server_query_uri
$r_server_query_xml = [xml]$r_server_query.Content
$r_server_list = $r_server_query_xml.EntityReferences.Ref

Write-Output $r_server_list

Stop-Transcript